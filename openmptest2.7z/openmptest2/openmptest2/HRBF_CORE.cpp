//
// Created by 73190 on 2022/10/13.
//
#include "HRBF_CORE.h"
#include "cmath"
#include "iostream"
using namespace std;



double HRBF_Core::Fai(Dot3D dot1, Dot3D dot2) {
    double dis = claDis(dot1, dot2);
    double fai = pow(dis, 3);
    return fai;
}

VectorXd HRBF_Core::Grad(Dot3D dot1, Dot3D dot2) {
//    double fai = Fai(dot1, dot2);
//    double x = 3 * fai * (dot1.x-dot2.x);
//    double y = 3 * fai * (dot1.y-dot2.y);
//    double z = 3 * fai * (dot1.z-dot2.z);

    double dis = claDis(dot1, dot2);
    double x = 3 * dis * (dot1.x-dot2.x);
    double y = 3 * dis * (dot1.y-dot2.y);
    double z = 3 * dis * (dot1.z-dot2.z);

    VectorXd grad(3);
    grad << x, y, z;
    return grad;
}

MatrixXd HRBF_Core::H(Dot3D dot1, Dot3D dot2) {
    Dot3D dot{};
    dot.x = dot1.x - dot2.x;
    dot.y = dot1.y - dot2.y;
    dot.z = dot1.z - dot2.z;
    double dis = claDis(dot1, dot2);
    double disCountdown = 1/dis;
    double xx = 3 * (dot.x * dot.x * disCountdown + dis);
    double yx = 3 * dot.x * dot.y * disCountdown;
    double zx = 3 * dot.x * dot.z * disCountdown;
    double yy = 3 * (dot.y * dot.y * disCountdown + dis);
    double zy = 3 * dot.y * dot.z * disCountdown;
    double zz = 3 * (dot.z * dot.z * disCountdown + dis);

    MatrixXd H(3, 3);
    H << xx, yx, zx,    yx, yy, zx,    zx, zy, zz;
    return H;
}

double HRBF_Core::claDis(Dot3D dot1, Dot3D dot2) {
    double dis = 0;
    dis =  sqrt(((dot1.x-dot2.x)*(dot1.x-dot2.x)+(dot1.y-dot2.y)*(dot1.y-dot2.y)+(dot1.z-dot2.z)*(dot1.z-dot2.z)));
    return dis;
}

MatrixXd HRBF_Core::claArf(vector<Dot3D> dotSet, vector<Dot3D> normalSet) {
    MatrixXd top(dotSet.size()*4, dotSet.size()*4);
    top.setZero();
    for(int i = 0; i < dotSet.size(); i++){
        for (int j = 0; j < dotSet.size(); j++){
            if (i < j){
                Dot3D dotI = dotSet[i];
                Dot3D dotJ = dotSet[j];
                double fai = Fai(dotI, dotJ);
                MatrixXd grad = Grad(dotI, dotJ);
                MatrixXd h = -1 * H(dotI, dotJ);
                top(i*4, j*4) = fai;
                top(i*4, j*4+1) = -grad(0, 0);
                top(i*4, j*4+2) = -grad(1);
                top(i*4, j*4+3) = -grad(2);
                top(i*4+1, j*4) = grad(0);
                top(i*4+2, j*4) = grad(1);
                top(i*4+3, j*4) = grad(2);

                top(i*4+1, j*4+1) = h(0, 0);
                top(i*4+1, j*4+2) = h(0, 1);
                top(i*4+1, j*4+3) = h(0, 2);
                top(i*4+2, j*4+1) = h(1, 0);
                top(i*4+2, j*4+2) = h(1, 1);
                top(i*4+2, j*4+3) = h(1, 2);
                top(i*4+3, j*4+1) = h(2, 0);
                top(i*4+3, j*4+2) = h(2, 1);
                top(i*4+3, j*4+3) = h(2, 2);
            }
        }
    }
//    cout<<top<<endl;
    MatrixXd A = top.transpose()+top;

    VectorXd C(normalSet.size() * 4);
    C.setZero();
    for(int i = 0; i < normalSet.size(); i++){
        C[i*4+1] = normalSet[i].x;
        C[i*4+2] = normalSet[i].y;
        C[i*4+3] = normalSet[i].z;
    }

    MatrixXd inverseA = A.inverse();
    MatrixXd arf = inverseA * C;
    return arf;
}

double HRBF_Core::claRes(Dot3D dot, vector<Dot3D> dotSet, MatrixXd arf) {
    double res = 0;
    for(int i = 0; i < dotSet.size(); i++){
        VectorXd beta(3);
        beta(0) = arf(i*4+1);
        beta(1) = arf(i*4+2);
        beta(2) = arf(i*4+3);
//        cout<<beta(0)<<endl;
        double w = beta.adjoint() * Grad(dot, dotSet[i]);
        res += (arf(i*4) * Fai(dot, dotSet[i])) - w;
    }
    return res;
}

vector<double> HRBF_Core::claDotsetRes(vector<Dot3D> reDotSet, vector<Dot3D> dotSet, MatrixXd arf) {
    vector<double> resSet;
    for(auto & i : reDotSet){
        double res = claRes(i, dotSet, arf);
        resSet.push_back(i.x);
        resSet.push_back(i.y);
        resSet.push_back(i.z);
        resSet.push_back(res);
    }
    return resSet;
}



