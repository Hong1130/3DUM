#include <iostream>
#include "omp.h"
#include <Eigen/Dense>
#include <vector>
#include <map>
#include "TYPE_Define.h"
#include "HRBF_CORE.h"
#include "tools.h"
using namespace std;
int main(int argc, char **argv) {
    string filename1 = R"(D:\GraduationProject\jiemian\data\jiemian4_6_points.csv)";
    string filename2 = R"(D:\GraduationProject\jiemian\data\jiemian4_6_normals.csv)";
    string filename4 = R"(D:\GraduationProject\jiemian\data\jiemian4_6_res.csv)";
    vector<string> stratigraphicFile;
    vector<string> normalFile;
    vector<string> reDotSetFile;
    vector<string> resFile;
    stratigraphicFile.insert(stratigraphicFile.end(), filename1);
    normalFile.insert(normalFile.end(), filename2);
    resFile.insert(resFile.end(), filename4);
    vector<Dot3D> DotSet = TOOLS::readDots(stratigraphicFile[0]);
    vector<Dot3D> NorSet = TOOLS::readDots(normalFile[0]);
    double xMin=275631.625, xMax=277312.25, yMin=3377625.5, yMax=3379208.25, zMin=71.2049,zMax=136.368;
    double precision =400;
    map<int, double[5][2]> oobSetOri = TOOLS::areaSubdivision2(xMin, xMax, yMin, yMax, zMin, zMax, precision); //子域划分
    map<int, DotPair> areaControlDotPairOri = TOOLS::controlPointAssignment(DotSet, NorSet, oobSetOri);//控制点分配
    vector<vector<double>> areaRes;
    map<int, double[5][2]> oobSet;
    map<int, DotPair> areaControlDotPair;
    int z = 0;
    for(map<int, DotPair>::iterator it = areaControlDotPairOri.begin(); it != areaControlDotPairOri.end();it++){
        if(it->second.coord.size() >2){
            oobSet[z][0][0] = oobSetOri[it->first][0][0];
            oobSet[z][0][1] = oobSetOri[it->first][0][1];
            oobSet[z][1][0] = oobSetOri[it->first][1][0];
            oobSet[z][1][1] = oobSetOri[it->first][1][1];
            oobSet[z][2][0] = oobSetOri[it->first][2][0];
            oobSet[z][2][1] = oobSetOri[it->first][2][1];
            oobSet[z][3][0] = oobSetOri[it->first][3][0];
            oobSet[z][3][1] = oobSetOri[it->first][3][1];
            oobSet[z][4][0] = oobSetOri[it->first][4][0];
            oobSet[z][4][1] = oobSetOri[it->first][4][1];
            areaControlDotPair[z] = it->second;
            z++;
        }
    }

    double x2Min = xMin+precision/2;
    double x2Max = xMax-precision/2;
    double y2Min = yMin+precision/2;
    double y2Max = yMax-precision/2;
    double z2Min = zMin+precision/2;
    double z2Max = zMax-precision/2;
    double precision2 = 2*precision;
    //二级子域划分
    map<int, double[5][2]> oobSet2Ori = TOOLS::areaSubdivision2(x2Min, x2Max, y2Min, y2Max, z2Min, z2Max, precision2); //子域划分
    map<int, DotPair> areaControlDotPair2Ori = TOOLS::controlPointAssignment(DotSet, NorSet, oobSet2Ori);//控制点分配
    map<int, double[5][2]> oobSet2;
    map<int, DotPair> areaControlDotPair2;
    z = 0;
    for(map<int, DotPair>::iterator it = areaControlDotPair2Ori.begin(); it != areaControlDotPair2Ori.end();it++){
        if(it->second.coord.size() > 2){
            oobSet2[z][0][0] = oobSet2Ori[it->first][0][0];
            oobSet2[z][0][1] = oobSet2Ori[it->first][0][1];
            oobSet2[z][1][0] = oobSet2Ori[it->first][1][0];
            oobSet2[z][1][1] = oobSet2Ori[it->first][1][1];
            oobSet2[z][2][0] = oobSet2Ori[it->first][2][0];
            oobSet2[z][2][1] = oobSet2Ori[it->first][2][1];
            oobSet2[z][3][0] = oobSet2Ori[it->first][3][0];
            oobSet2[z][3][1] = oobSet2Ori[it->first][3][1];
            oobSet2[z][4][0] = oobSet2Ori[it->first][4][0];
            oobSet2[z][4][1] = oobSet2Ori[it->first][4][1];
            areaControlDotPair2[z] = it->second;
            z++;
        }
    }
    map<int, MatrixXd> arfSet2;
    map<int, vector<Dot3D>> reDotSet2;
    map<int, vector<double>> resSet2;
    //设置线程数，一般设置的线程数不超过CPU核心数，这里开4个线程执行并行代码段
//    omp_set_num_threads(2);
    double start = omp_get_wtime( );
//    vector<int> testVector;
    omp_set_num_threads(12);
    int pointnum = 0;
    map<int, MatrixXd> arfSet;
    map<int, vector<Dot3D>> reDotSet;
    map<int, vector<double>> resSet;
    cout<<1<<endl;
#pragma omp parallel
    {
#pragma omp for
        for(int i = 0; i< oobSet.size(); i++){
                //#pragma omp critical
//                int level = TOOLS::claSegmentationLevel(areaControlDotPair[i]);
////            double areaPrecision = 10;
//                double xMin = oobSet[i][0][0];
//                double yMin = oobSet[i][0][1];
//                double zMin = oobSet[i][4][0];
//                double xMax = oobSet[i][1][0];
//                double yMax = oobSet[i][2][1];
//                double zMax = oobSet[i][4][1];
                int level = TOOLS::claSegmentationLevel(areaControlDotPair[i]);
//                cout<<level<<endl;
                reDotSet[i] = TOOLS::spaceSubdivision(oobSet[i][0][0], oobSet[i][1][0], oobSet[i][0][1],  oobSet[i][2][1], oobSet[i][4][0], oobSet[i][4][1], level);
//                cout<<reDotSet[i].size()<<endl;
//#pragma omp critical
//            pointnum+=reDotSet[i].size();
//                pointnum += reDotSet.size();
//                cout<<pointnum<<endl;
                 arfSet[i] = HRBF_Core::claArf(areaControlDotPair[i].coord, areaControlDotPair[i].normal);
                 MatrixXd arf = HRBF_Core::claArf(areaControlDotPair[i].coord, areaControlDotPair[i].normal);
//                cout<<arf<<endl;
//                vector<double> res = HRBF_Core::claDotsetRes(reDotSet[i], areaControlDotPair[i].coord, arfSet[i]);
                resSet[i] = HRBF_Core::claDotsetRes(reDotSet[i], areaControlDotPair[i].coord, arfSet[i]);
//#pragma omp critical
//                areaRes.push_back(resSet[i]);
//            printf("i = %d, I am Thread %d\n", i, omp_get_thread_num());

        }
    }
//#pragma omp single
//    {
//        int num = 0;
//        for(map<int, vector<Dot3D>>::iterator it = reDotSet.begin(); it != reDotSet.end();it++){
//            num+=it->second.size();
//        }
//        cout<<num<<endl;
//    }
#pragma omp parallel
    {
#pragma omp for
        for(int i = 0; i< oobSet2.size(); i++){
//#pragma omp critical
//            double areaPrecision = 2*precision;
//            double xMin2 = oobSet2[i][0][0];
//            double yMin2 = oobSet2[i][0][1];
//            double zMin2 = oobSet2[i][4][0];
//            double xMax2 = oobSet2[i][1][0];
//            double yMax2 = oobSet2[i][2][1];
//            double zMax2 = oobSet2[i][4][1];
//            int level2 = TOOLS::claSegmentationLevel(areaControlDotPair2[i]);
//            Dot3D minDot = {xMin2, yMin2, zMin2};
//            vector<Dot3D> reDotSet2 = TOOLS::spaceSubdivision(minDot, precision, level2);
            reDotSet2[i] = TOOLS::spaceSubdivision(oobSet2[i][0][0], oobSet2[i][0][1],oobSet2[i][4][0], precision2, TOOLS::claSegmentationLevel(areaControlDotPair2[i]));
//            MatrixXd arf2 = HRBF_Core::claArf(areaControlDotPair2[i].coord, areaControlDotPair2[i].normal);
            arfSet2[i] = HRBF_Core::claArf(areaControlDotPair2[i].coord, areaControlDotPair2[i].normal);
            resSet2[i] = HRBF_Core::claDotsetRes(reDotSet2[i], areaControlDotPair2[i].coord, arfSet2[i]);
//            vector<double> res = HRBF_Core::claDotsetRes(reDotSet2, areaControlDotPair2[i].coord, arf2);
//#pragma omp critical

//            areaRes.push_back(resSet2[i]);
//            printf("i = %d, I am Thread %d\n", i, omp_get_thread_num());
        }
    }

    double end = omp_get_wtime( );
    cout<<end-start<<endl;
//    cout<<pointnum<<endl;
//    String fileName = "./result";
//    TOOLS::writeToTxt(areaRes, fileName);




//    for(int i = 0; i < 10; i++){
//        cout<< testVector[i]<<endl;
//    }
}
