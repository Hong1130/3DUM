//
// Created by 73190 on 2022/10/17.
//
#include "iostream"
#include <string>
#include <fstream>
#include <sstream>
#include <map>
#include "tools.h"
#include "cmath"
#include "HRBF_CORE.h"
using namespace std;

//double TOOLS::claAngle(pcl::Normal n1, pcl::Normal n2) {
//
//    double d1Length = sqrt(n1.normal_x*n1.normal_x+n1.normal_y*n1.normal_y+n1.normal_z*n1.normal_z);
//    double d2Length = sqrt(n2.normal_x*n2.normal_x+n2.normal_y*n2.normal_y+n2.normal_z*n2.normal_z);
//    double cosAngle = (n1.normal_x*n2.normal_x + n1.normal_y*n2.normal_y + n1.normal_z*n2.normal_z)/(d1Length*d2Length);
//    double angle = acos(cosAngle);
//
//    return angle;
//}

//void TOOLS::toPCD(const string& inputFilename, const string& ouputFilename) {
//    fstream modelRead;
//    pcl::PointCloud<pcl::PointXYZ> cloud;
//    pcl::PCDWriter writer;
//
//    modelRead.open(inputFilename,std::ios_base::in);
//    pcl::PointXYZ pclPnt;
//    while(!modelRead.eof())
//    {
//        modelRead>>pclPnt.x>>pclPnt.y>>pclPnt.z;
//        cloud.push_back(pclPnt);
//    }
//    modelRead.close();
//    writer.write(ouputFilename,cloud);
//}

//pcl::PointCloud<pcl::PointXYZ> TOOLS::toPCD(const string &inputFilename) {
//    fstream modelRead;
//    pcl::PointCloud<pcl::PointXYZ> cloud;
//    pcl::PCDWriter writer;
//
//    modelRead.open(inputFilename,std::ios_base::in);
//    pcl::PointXYZ pclPnt;
//    while(!modelRead.eof())
//    {
//        modelRead>>pclPnt.x>>pclPnt.y>>pclPnt.z;
//        cloud.push_back(pclPnt);
//    }
//    modelRead.close();
//
//    return cloud;
//}

//double TOOLS::claAvgAngle(pcl::PointCloud<pcl::PointXYZINormal> cloud) {
//    double sumX = 0;
//    double sumY = 0;
//
//    double length = cloud.points.size();
//    for(auto & i : cloud){
//        sumX += i.x;
//        sumY += i.y;
//    }
//    double avgX = sumX/length;
//    double avgY = sumY/length;
//
//    Dot3D centerDot = {cloud[0].x, cloud[0].y, cloud[0].z};
//    int index = 0;
//    double distance = (centerDot.x-avgX)*(centerDot.x-avgX) + (centerDot.y-avgY)*(centerDot.y-avgY);
//    for(int i = 0; i < length; i++){
//        double d = (cloud[i].x-avgX)*(cloud[i].x-avgX) + (cloud[i].y-avgY)*(cloud[i].y-avgY);
//        if(d < distance){
//            distance = d;
//            centerDot.x = cloud[i].x;
//            centerDot.y = cloud[i].y;
//            centerDot.z = cloud[i].z;
//            index = i;
//        }
//    }
//
//    double sumAngle = 0;
//    pcl::Normal n1;
//    n1.normal_x = cloud[index].normal_x;
//    n1.normal_y = cloud[index].normal_y;
//    n1.normal_z = cloud[index].normal_z;
//    for(int i = 0; i < length; i++){
//        pcl::Normal n2;
//        n2.normal_x = cloud[i].normal_x;
//        n2.normal_y = cloud[i].normal_y;
//        n2.normal_z = cloud[i].normal_z;
//        sumAngle += claAngle(n1, n2);
//    }
//    double avgAngle = sumAngle/length;
//    return avgAngle;
//}

vector<Dot3D> TOOLS::readDots(const string& fileName) {
    ifstream inFile(fileName, ios::in);
    if (!inFile)
    {
        cout<<"fail to open the file"<<endl;
        exit(1);
    }

    int i = 0;
    string line;
//    string field;
    vector<Dot3D> dotSet;
    while (getline(inFile, line))//getline(inFile, line)表示按行读取CSV文件中的数据
    {
        Dot3D dot = {};
        string field;
        istringstream sin(line); //将整行字符串line读入到字符串流sin中

        getline(sin, field, ','); //将字符串流sin中的字符读入到field字符串中，以逗号为分隔符

        dot.x = stod(field.c_str());
        getline(sin, field, ','); //将字符串流sin中的字符读入到field字符串中，以逗号为分隔符

        dot.y = stod(field.c_str());
        getline(sin, field, ','); //将字符串流sin中的字符读入到field字符串中，以逗号为分隔符

        dot.z = stod(field.c_str());
        getline(sin, field); //将字符串流sin中的字符读入到field字符串中，以逗号为分隔符

        dotSet.push_back(dot);
        i++;
    }
    inFile.close();
    cout <<"read finished"<< endl;
    return dotSet;
}

vector<Dot3D> TOOLS::spaceSubdivision(double xMin, double xMax, double yMin, double yMAX, double zMin, double zMax, double precision) {
    int xCount =ceil((xMax-xMin)/precision);
    int yCount =ceil((yMAX-yMin)/precision);
    int zCount =ceil((zMax-zMin)/2);
    vector<Dot3D> gridDotSet;
    for(int i = 0; i < zCount; i++){
        for(int j = 0; j < yCount; j++){
            for(int k = 0; k < xCount; k++){
                Dot3D d1 = {xMin + k*precision, yMin + j*precision, zMin + i*2};
                gridDotSet.push_back(d1);
            }
        }
    }
//    cout<<gridDotSet.size()<<endl;
    return gridDotSet;
}

int TOOLS::claSegmentationLevel(DotPair dotsSet) {
    int count = dotsSet.coord.size();
    double minZ = 9999;
    double maxZ = 0;
    for(int i = 0; i < count; i++){
        minZ = minZ > dotsSet.coord[i].z ? dotsSet.coord[i].z : minZ;
        maxZ = maxZ < dotsSet.coord[i].z ? dotsSet.coord[i].z : maxZ;
    }
    double t =0.03;
    double diff = maxZ - minZ;
    if(diff > 1500*t){
        return 1;
    } else if (diff>500*t && diff<1500*t){
        return 2;
    } else if (diff>200*t && diff<500*t){
        return 3;
    } else if (diff>20*t && diff<200*t){
        return 4;
    } else{
        return 5;
    }
}

bool TOOLS::isInner(Dot3D dot, double xMin, double xMax, double yMin, double yMAX) {
    if(dot.x>=xMin && dot.x <=xMax && dot.y>=yMin && dot.y<=yMAX){
        return true;
    }
    return false;
}

//存储每个格网起始点
map<int, Dot3D>
TOOLS::areaSubdivision(double xMin, double xMax, double yMin, double yMax, double zMin, double zMax, double precision) {
    int xCount = ceil((xMax-xMin)/precision);
    int yCount = ceil((yMax-yMin)/precision);
    int zCount = ceil((zMax-zMin)/precision);
//    vector<Dot3D> gridMinDot;
    map<int, Dot3D> mapGridMinDot;
    for(int i = 0; i < zCount-1; i++){
        for(int j = 0; j < yCount-1; j++){
            for(int k = 0; k < xCount-1; k++){
                Dot3D dot = {xMin + k*precision, yMin + j*precision, zMin + i*precision};
                int areaDotLineNum = ceil((dot.x - xMin)/precision);
                int areaDotColumnNum = ceil((dot.y - yMin)/precision);
                int areaDotLayerNum = ceil((dot.z - zMin)/precision);
                int index = areaDotLineNum*100 + areaDotColumnNum*10+areaDotLayerNum;
                mapGridMinDot[index] = dot;
            }
        }
    }

    return mapGridMinDot;
}
map<int, double[5][2]>
TOOLS::areaSubdivision2(double xMin, double xMax, double yMin, double yMAX, double zMin, double zMax, double precision){
    int xNum =ceil((xMax-xMin)/precision);
    int yNum =ceil((yMAX-yMin)/precision);
    double xSet[xNum];
    double ySet[yNum];
    for(int i = 0; i < xNum+1; i++){
        xSet[i] = xMin+i*precision;
    }
    for(int i = 0; i < yNum+1; i++){
        ySet[i] = yMin+i*precision;
    }
    map<int, double[5][2]> result;
    int indexX = xNum;
    for(int i = 0; i < xNum; i++){
        for(int j = 0; j < yNum; j++){
            result[indexX*i+j][0][0] = xSet[j];
            result[indexX*i+j][0][1] = ySet[i];
            result[indexX*i+j][1][0] = xSet[j+1];
            result[indexX*i+j][1][1] = ySet[i];
            result[indexX*i+j][2][0] = xSet[j];
            result[indexX*i+j][2][1] = ySet[i+1];
            result[indexX*i+j][3][0] = xSet[j+1];
            result[indexX*i+j][3][1] = ySet[i+1];
            result[indexX*i+j][4][0] = zMin;
            result[indexX*i+j][4][1] = zMax;
        }
    }
    return result;
}


//配分控制点至各个子域
map<int, DotPair*>
TOOLS::controlPointAssignment(vector<Dot3D> DotSet, vector<Dot3D> NorSet, double precision, double xMin,  double yMin,  double zMin) {
    map<int, DotPair*> areaControlDotPair;
    map<int, vector<Dot3D>> dotMap;
    map<int, vector<Dot3D>> norMap;

    for(int i = 0; i < DotSet.size(); i++){
        int controlDotLineNum = ceil((DotSet[i].x - xMin)/precision);
        int controlDotColumnNum = ceil((DotSet[i].y - yMin)/precision);
        int controlDotLayerNum = ceil((DotSet[i].z - zMin)/precision);
        int index = controlDotLineNum*100 + controlDotColumnNum*10+controlDotLayerNum;
        dotMap[index].push_back(DotSet[i]);
        norMap[index].push_back(NorSet[i]);
    }
    for(auto iter = dotMap.begin(); iter != dotMap.end(); ++iter){
        DotPair pair = {dotMap[iter->first], norMap[iter->first]};
        int index = iter->first;
        areaControlDotPair[index] = &pair;
//        areaControlDotPair[index].normal = dotMap[iter->first];
    }

    return areaControlDotPair;
}

map<int, DotPair>
TOOLS::controlPointAssignment(vector<Dot3D> DotSet, vector<Dot3D> NorSet, map<int, double[5][2]> oobSet){
    map<int, DotPair> areaControlDotPair;
    map<int, vector<Dot3D>> dotMap;
    map<int, vector<Dot3D>> norMap;

    for(int i = 0; i < DotSet.size(); i++){
        for(int j = 0; j < oobSet.size(); j++){
            if (isInner(DotSet[i], oobSet[j][0][0], oobSet[j][1][0], oobSet[j][0][1], oobSet[j][2][1])){
                dotMap[j].push_back(DotSet[i]);
                norMap[j].push_back(NorSet[i]);
                break;
            }
        }
    }
    for(auto iter = dotMap.begin(); iter != dotMap.end(); ++iter){
        DotPair pair = {dotMap[iter->first], norMap[iter->first]};
        int index = iter->first;
        areaControlDotPair[index] = pair;
//        areaControlDotPair[index].normal = dotMap[iter->first];
    }
    return areaControlDotPair;
}



vector<Dot3D> TOOLS::spaceSubdivision(Dot3D mapGridMinDot, double precision, double level2) {
    double r = precision/2;
    vector<Dot3D> reDot;
    double x1Min = mapGridMinDot.x+(1/4)*r;
    double x1Max = mapGridMinDot.x+(7/4)*r;
    double y1Min = mapGridMinDot.y+(1/4)*r;
    double y1Max = mapGridMinDot.y+(1/2)*r;
    double z1Min = mapGridMinDot.z+(1/4)*r;
    double z1Max = mapGridMinDot.z+(7/4)*r;
    vector<Dot3D> g1 = spaceSubdivision(x1Min, x1Max, y1Min, y1Max, z1Min, z1Max, level2);
    double x2Min = mapGridMinDot.x+(1/4)*r;
    double x2Max = mapGridMinDot.x+(7/4)*r;
    double y2Min = mapGridMinDot.y+(3/2)*r;
    double y2Max = mapGridMinDot.y+(7/4)*r;
    double z2Min = mapGridMinDot.z+(1/4)*r;
    double z2Max = mapGridMinDot.z+(7/4)*r;
    vector<Dot3D> g2 = spaceSubdivision(x2Min, x2Max, y2Min, y2Max, z2Min, z2Max, level2);
    double x3Min = mapGridMinDot.x+(1/4)*r;
    double x3Max = mapGridMinDot.x+(1/2)*r;
    double y3Min = mapGridMinDot.y+(1/4)*r;
    double y3Max = mapGridMinDot.y+(3/2)*r;
    double z3Min = mapGridMinDot.z+(1/4)*r;
    double z3Max = mapGridMinDot.z+(7/4)*r;
    vector<Dot3D> g3 = spaceSubdivision(x3Min, x3Max, y3Min, y3Max, z3Min, z3Max, level2);
    double x4Min = mapGridMinDot.x+(3/2)*r;
    double x4Max = mapGridMinDot.x+(7/4)*r;
    double y4Min = mapGridMinDot.y+(1/2)*r;
    double y4Max = mapGridMinDot.y+(3/2)*r;
    double z4Min = mapGridMinDot.z+(1/4)*r;
    double z4Max = mapGridMinDot.z+(7/4)*r;
    vector<Dot3D> g4 = spaceSubdivision(x4Min, x4Max, y4Min, y4Max, z4Min, z4Max, level2);
    reDot.insert(reDot.end(), g1.begin(), g1.end());
    reDot.insert(reDot.end(), g2.begin(), g2.end());
    reDot.insert(reDot.end(), g3.begin(), g3.end());
    reDot.insert(reDot.end(), g4.begin(), g4.end());
    return reDot;
}

vector<Dot3D> TOOLS::spaceSubdivision(double xMin, double yMin, double zMin, double precision, double level2) {
    double r = precision/2;
    vector<Dot3D> reDot;
    double x1Min = xMin+(1/4)*r;
    double x1Max = xMin+(7/4)*r;
    double y1Min = yMin+(1/4)*r;
    double y1Max = yMin+(1/2)*r;
    double z1Min = zMin+(1/4)*10;
    double z1Max = zMin+(7/4)*10;
    vector<Dot3D> g1 = spaceSubdivision(x1Min, x1Max, y1Min, y1Max, z1Min, z1Max, level2);
    double x2Min = xMin+(1/4)*r;
    double x2Max = xMin+(7/4)*r;
    double y2Min = yMin+(3/2)*r;
    double y2Max = yMin+(7/4)*r;
    double z2Min = zMin+(1/4)*10;
    double z2Max = zMin+(7/4)*10;
    vector<Dot3D> g2 = spaceSubdivision(x2Min, x2Max, y2Min, y2Max, z2Min, z2Max, level2);
    double x3Min = xMin+(1/4)*r;
    double x3Max = xMin+(1/2)*r;
    double y3Min = yMin+(1/4)*r;
    double y3Max = yMin+(3/2)*r;
    double z3Min = zMin+(1/4)*10;
    double z3Max = zMin+(7/4)*10;
    vector<Dot3D> g3 = spaceSubdivision(x3Min, x3Max, y3Min, y3Max, z3Min, z3Max, level2);
    double x4Min = xMin+(3/2)*r;
    double x4Max = xMin+(7/4)*r;
    double y4Min = yMin+(1/2)*r;
    double y4Max = yMin+(3/2)*r;
    double z4Min = zMin+(1/4)*10;
    double z4Max = zMin+(7/4)*10;
    vector<Dot3D> g4 = spaceSubdivision(x4Min, x4Max, y4Min, y4Max, z4Min, z4Max, level2);
    reDot.insert(reDot.end(), g1.begin(), g1.end());
    reDot.insert(reDot.end(), g2.begin(), g2.end());
    reDot.insert(reDot.end(), g3.begin(), g3.end());
    reDot.insert(reDot.end(), g4.begin(), g4.end());
    return reDot;
}
void TOOLS::writeToTxt(vector<vector<double>> coordWithRes, string fileName) {
    ofstream f(fileName, ios::app);
    for(int i = 0; i < coordWithRes.size(); i++){
        f<<coordWithRes[i][0]<<" ";
        f<<coordWithRes[i][1]<<" ";
        f<<coordWithRes[i][2]<<" ";
    }

}

//pcl::PointCloud<pcl::PointXYZINormal> TOOLS::claNormals(pcl::PointCloud<pcl::PointXYZ> cloud) {
//    pcl::PointCloud<pcl::PointXYZ>::Ptr cloudPtr(new pcl::PointCloud<pcl::PointXYZ>);
//    cloudPtr = cloud.makeShared();
//
//    pcl::NormalEstimationOMP<pcl::PointXYZ, pcl::Normal> n;//OMP加速
//    pcl::PointCloud<pcl::Normal>::Ptr normals(new pcl::PointCloud<pcl::Normal>);
//    //建立kdtree来进行近邻点集搜索
//    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>());
//    n.setNumberOfThreads(10);//设置openMP的线程数
//
//    n.setInputCloud(cloudPtr);
//    n.setSearchMethod(tree);
//    n.setKSearch(20);//点云法向计算时，需要所搜的近邻点大小
//    n.setViewPoint(0.0,0.0,0.1);//设置视点，默认为（0，0，0）
////    n.setRadiusSearch(300000);//半径搜素
//    n.compute(*normals);//开始进行法向计
//    pcl::PointCloud<pcl::PointXYZINormal>::Ptr cloud_with_normals(new pcl::PointCloud<pcl::PointXYZINormal>);
//    pcl::concatenateFields(*cloudPtr, *normals, *cloud_with_normals);
//    pcl::io::savePCDFileASCII<pcl::PointXYZINormal>(R"(D:\GraduationProject\test\dem2.pcd)", *cloud_with_normals); //ASCII方式保存
//
//    //-------------------------- 法线可视化 --------------------------
//    boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer(new pcl::visualization::PCLVisualizer("3D Viewer")); //创建视窗对象，定义标题栏名称“3D Viewer”
//    viewer->addPointCloud<pcl::PointXYZ>(cloudPtr, "original_cloud");	//将点云添加到视窗对象中，并定义一个唯一的ID“original_cloud”
//    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 1, 0, 0.5, "original_cloud"); //点云附色，三个字段，每个字段范围0-1
//    viewer->addPointCloudNormals<pcl::PointXYZ, pcl::Normal>(cloudPtr, normals, 1, 10, "normals");	//每十个点显示一个法线，长度为0.05
//    while (!viewer->wasStopped())
//    {
//        viewer->spinOnce(100);
////        boost::this_thread::sleep(boost::posix_time::microseconds(100000));
//    }
//
//    return *cloud_with_normals;
//
//
//}




