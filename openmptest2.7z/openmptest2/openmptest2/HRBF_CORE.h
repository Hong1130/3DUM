//
// Created by 73190 on 2022/10/13.
//

#ifndef HRBF3_HRBF_CORE_H
#define HRBF3_HRBF_CORE_H
#include <Eigen/Dense>
#include "vector"
#include "TYPE_Define.h"

using namespace std;
using Eigen::MatrixXd;
using Eigen::VectorXd;


class HRBF_Core{
public:
    static double Fai(Dot3D dot1, Dot3D dot2);
    static VectorXd Grad(Dot3D dot1, Dot3D dot2);
    static MatrixXd H(Dot3D dot1, Dot3D dot2);
    static double claDis(Dot3D dot1, Dot3D dot2);
    static MatrixXd claArf(vector<Dot3D> dotSet, vector<Dot3D> normalSet);
    static double claRes(Dot3D dot, vector<Dot3D> dotSet, MatrixXd arf);
    static vector<double> claDotsetRes(vector<Dot3D> reDotSet, vector<Dot3D> dotSet, MatrixXd arf);
//private:
//    MatrixXd alpha;
//    MatrixXd beta;

};







#endif //HRBF3_HRBF_CORE_H
