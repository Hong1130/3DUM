#include <utility>
#include "vector"
//
// Created by 73190 on 2022/10/17.
//

#ifndef HRBF3_TYPE_DEFINE_H
#define HRBF3_TYPE_DEFINE_H
using namespace std;
struct Dot3D
{
    double x;
    double y;
    double z;
};
struct Grid{
    Dot3D d0;
    Dot3D d1;
    Dot3D d2;
    Dot3D d3;
    Dot3D d4;
    Dot3D d5;
    Dot3D d6;
    Dot3D d7;
};
struct DotPair{
//    DotPair()= default;;
//    DotPair(vector<Dot3D> coord, vector<Dot3D> normal) : coord(std::move(coord)), normal(std::move(normal)){};
    vector<Dot3D> coord;
    vector<Dot3D> normal;
};
class TYPE_Define {

};


#endif //HRBF3_TYPE_DEFINE_H
