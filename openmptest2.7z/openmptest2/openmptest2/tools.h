//
// Created by 73190 on 2022/10/17.
//

#ifndef HRBF3_TOOLS_H
#define HRBF3_TOOLS_H
//#include <Eigen/Dense>
//#include <pcl/io/pcd_io.h>
//#include <pcl/point_types.h>
#include "TYPE_Define.h"
#include "HRBF_CORE.h"
using namespace std;
using Eigen::MatrixXd;
using Eigen::VectorXd;


class TOOLS{
public:
//    static double claAngle(pcl::Normal n1, pcl::Normal n2);
//    static void toPCD(const string& inputFilename, const string& ouputFilename);
//    static pcl::PointCloud<pcl::PointXYZ> toPCD(const string& inputFilename);
//    static double claAvgAngle(pcl::PointCloud<pcl::PointXYZINormal> cloud);
//    static pcl::PointCloud<pcl::PointXYZINormal> claNormals(pcl::PointCloud<pcl::PointXYZ> cloud);
    static vector<Dot3D> readDots(const string& fileName);
    static vector<Dot3D> spaceSubdivision(double xMin, double xMax, double yMin, double yMAX, double zMin, double zMax, double precision);
    static int claSegmentationLevel(DotPair dotsSet);
    static bool isInner(Dot3D dot, double xMin, double xMax, double yMin, double yMAX);
    static map<int, Dot3D> areaSubdivision(double xMin, double xMax, double yMin, double yMAX, double zMin, double zMax, double precision);
    static map<int, double[5][2]> areaSubdivision2(double xMin, double xMax, double yMin, double yMAX, double zMin, double zMax, double precision);
    static map<int, DotPair*> controlPointAssignment(vector<Dot3D> DotSet, vector<Dot3D> NorSet, double precision, double xMin, double yMin, double zMin);
    static map<int, DotPair> controlPointAssignment(vector<Dot3D> DotSet, vector<Dot3D> NorSet, map<int, double[5][2]> oobSet);
    static vector<Dot3D> spaceSubdivision(Dot3D mapGridMinDot, double precision, double level2);
    static vector<Dot3D> spaceSubdivision(double xMin, double yMin, double zMin, double precision, double level2);
    static void writeToTxt(vector<vector<double>> coordWithRes, string fileName);
    };

#endif //HRBF3_TOOLS_H
